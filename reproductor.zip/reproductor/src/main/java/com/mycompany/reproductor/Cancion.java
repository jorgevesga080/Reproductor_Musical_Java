package com.mycompany.reproductor;

public class Cancion {
    private String titulo;
    private String artista;
    private boolean Favorita;

    public Cancion(String titulo, String artista) {
        this.titulo = titulo;
        this.artista = artista;
        this.Favorita = false;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public boolean isFavorita() {
        return Favorita;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public void setFavorita(boolean Favorita) {
        this.Favorita = Favorita;
    }
    
    public String mostrarInfo(){
    return "Cancion: " + titulo + "--" + artista + "Cancion Favorita: " + Favorita;
    }
    
    
}
