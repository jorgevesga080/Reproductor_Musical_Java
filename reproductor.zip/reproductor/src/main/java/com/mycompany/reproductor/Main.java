package com.mycompany.reproductor;

public class Main {
    public static void main(String[] args){
        
        Cancion c1 = new Cancion("Mil horas"," Los Abuelos de la Nada.");
        Cancion c2 = new Cancion("Por ese hombre"," Fandango.");
        Cancion c3 = new Cancion("A esa"," Franco De Vita.");
        Cancion c4 = new Cancion("Algo de mi"," Franco De Vita.");
        Cancion c5 = new Cancion("Si me dejas ahora"," Camilo Sesto.");
        
        ListaCanciones lista=new ListaCanciones(10);
        lista.agregarCancion(c1);
        lista.agregarCancion(c2);
        lista.agregarCancion(c3);
        lista.agregarCancion(c4);
        lista.agregarCancion(c5);
        lista.mostrarTodas();
        
        Reproductor reproductor = new Reproductor(lista);
        
        reproductor.mostrarEstado();
        reproductor.cambiarEstadoReproduccion();
        reproductor.proximaCancion();
        reproductor.devolverCancion();
        reproductor.agregarCancionFavorita();
        lista.mostrarFavoritas();
    }
}
