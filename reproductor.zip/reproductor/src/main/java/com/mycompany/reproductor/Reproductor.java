package com.mycompany.reproductor;

public class Reproductor {
    
    private ListaCanciones listaCanciones;
    private boolean pausado;
    private int cancionReproduciendo;

    public Reproductor(ListaCanciones listaCanciones) {
        this.listaCanciones = listaCanciones;
        this.pausado = true;
        this.cancionReproduciendo = 0;
    }
    
    public void proximaCancion() {
        cancionReproduciendo = (cancionReproduciendo + 1) 
        % listaCanciones.getTotalCanciones();
        System.out.println("Siguiente cancion: " + 
        getCancionActual().mostrarInfo());
    }
    
    public void devolverCancion(){
        cancionReproduciendo = (cancionReproduciendo + listaCanciones.getTotalCanciones()-1) 
                % listaCanciones.getTotalCanciones();
        System.out.println(" Cancion Anterior: " + getCancionActual().mostrarInfo());
    }
    
       public void cambiarEstadoReproduccion() {
        pausado = !pausado;
        if (pausado) {
            System.out.println("Pausado: " + getCancionActual().getTitulo());
        } else {
            System.out.println("Reproduciendo: " + getCancionActual().getTitulo());
        }
    }
    
    public void agregarCancionFavorita() {
        listaCanciones.marcarFavorita(cancionReproduciendo);
    }
    
        public Cancion getCancionActual() {
        return listaCanciones.getCancion(cancionReproduciendo);
    }
    
    public void mostrarEstado() {
    System.out.println("\n=============================");
    System.out.println("ESTADO DEL REPRODUCTOR");
    System.out.println("=============================");
    System.out.println("Cancion actual : " + getCancionActual().mostrarInfo());
    System.out.println("Estado         : " + (pausado ? "Pausado" : "Reproduciendo"));
    System.out.println("=============================\n");
    }
    
    public boolean isPausado() {
        return pausado;
    }

    public int getCancionReproduciendo() {
        return cancionReproduciendo;
    }
}