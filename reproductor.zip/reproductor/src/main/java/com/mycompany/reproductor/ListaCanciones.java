package com.mycompany.reproductor;

public class ListaCanciones {
    private Cancion[] canciones;
    private int totalCanciones;

    public ListaCanciones(int capacidadMaxima) {
        this.canciones = new Cancion[capacidadMaxima];
        this.totalCanciones = 0;
    }
    
    public void agregarCancion(Cancion cancion){
    if (totalCanciones < canciones.length){
        canciones[totalCanciones]= cancion;
        totalCanciones++;
        System.out.println("Cancion: " + cancion.getTitulo() + "agregada con exito");
    }
    else{
        System.out.println("No se puede agregar la cancion porque la lista esta llena.");
    }
    }
    
    
    public Cancion getCancion(int indice){
        if(indice >= 0 && indice < totalCanciones){
            return canciones[indice];
        }
        return null;
    }
    
    public void marcarFavorita(int indice){
        Cancion cancion = getCancion(indice);
        if (cancion != null){
            if(!cancion.isFavorita()){
                cancion.setFavorita(true);
                System.out.println("Cancion: "+cancion.getTitulo()+" Agreagada a Favoritos.");
            }
            else{
                System.out.println("Cancion: " + cancion.getTitulo()+" Ya esta en favoritos.");
            }
        }
    }
    
    public void mostrarFavoritas(){
        System.out.println("\n== CANCIONES FAVORITAS ===");
        boolean hayFavoritas = false;
        for (int i = 0; i < totalCanciones; i++) {
            if(canciones[i].isFavorita()){
                System.out.println(" " + canciones[i].mostrarInfo());
                hayFavoritas = true;
                }
            }
        if (!hayFavoritas){
            System.out.println(" No hay canciones favoritas aún. ");
            }
        }
    
    public void mostrarTodas(){
        System.out.println("\n=== TODAS LAS CANCIONES ===");
        for(int i=0; i<totalCanciones; i++){
            System.out.println(" [" + i + "] " + canciones[i].mostrarInfo());
        }
    }
    
    public int getTotalCanciones() {
        return totalCanciones;
    }
}
